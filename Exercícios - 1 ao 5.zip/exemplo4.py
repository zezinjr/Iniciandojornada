#Calculando INSS
faixa_salarial = float(input("Digite seu salário: "))
print(f"O salário bruto é de {faixa_salarial} reais")

if faixa_salarial > 0 and faixa_salarial <= 1518:
    valor_inss = (faixa_salarial * 0.075)
    print(f"O valor pago de INSS é {round(valor_inss,2)} reais.")
elif faixa_salarial > 1518 and faixa_salarial <= 2793.88:
    valor_inss = (faixa_salarial * 0.09) - 22.77
    print(f"O valor pago de INSS é {round(valor_inss,2)} reais.")
elif faixa_salarial > 2793.88 and faixa_salarial <= 4190.83:
    valor_inss = (faixa_salarial * 0.12) - 106.59
    print(f"O valor pago de INSS é {round(valor_inss,2)} reais.")
elif faixa_salarial > 4190.83 and faixa_salarial <= 8157.41:
    valor_inss = (faixa_salarial * 0.14) - 190.40
    print(f"O valor pago de INSS é {round(valor_inss,2)} reais.")
else:
    print("O valor é menor que 0 ou está fora das relações listadas.")

#Calculando IR
if faixa_salarial < 2428.81:
    valor_ir = 0
    print(f"O valor pago de IR é {round(valor_ir, 2)} reais.")
elif faixa_salarial >= 2428.81 and faixa_salarial <= 2826.65:
    base = faixa_salarial - valor_inss
    valor_ir = (base * 0.075) - 182.16
    print(f"O valor pago de IR2 é {round(valor_ir, 2)} reais.")
elif faixa_salarial >= 2826.66 and faixa_salarial <= 3751.05:
    base = faixa_salarial - valor_inss
    valor_ir = (base * 0.15) - 394.16
    print(f"O valor pago de IR é {round(valor_ir, 2)} reais.")
elif faixa_salarial >= 3751.06 and faixa_salarial <= 4664.68:
    base = faixa_salarial - valor_inss
    valor_ir = (base * 0.225) - 675.49
    print(f"O valor pago de IR é {round(valor_ir, 2)} reais.")
elif faixa_salarial > 4664.68:
    base = faixa_salarial - valor_inss
    valor_ir = (base * 0.275) - 908.73
    print(f"O valor pago de IR é {round(valor_ir, 2)} reais.")

salario_liquido = faixa_salarial - valor_inss - valor_ir
print(f"O salário líquido é de {round(salario_liquido, 2)} reais.")