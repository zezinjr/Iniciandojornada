h = float(input("Digite o valor da sua altura: "))
opcao = input("Escolha uma opção:")

match opcao:
    case "H":
        peso_ideal_homens = (72.7 * h) - 58
        print(f"Seu peso ideal é {round(peso_ideal_homens,2)} kg.")
    case "M":
        peso_ideal_mulheres = (62.1 * h) - 44.7
        print(f"Seu peso ideal é {round(peso_ideal_mulheres,2)} kg.")
    case _:
        print("Opção inválida.")