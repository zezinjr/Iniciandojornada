numero = int(input("Digite um número:"))

if numero > 0 and numero <= 10:
    for i in range(1,11):
        multicplicar = numero * i
        print(f"{numero} x {i} = {multicplicar}")
else:
    print("O valor não está entre 1 a 10")