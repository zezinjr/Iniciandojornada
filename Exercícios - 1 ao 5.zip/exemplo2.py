F = float(input("Digite uma temperatura em Fahrenheit: "))

C = 5 * ((F-32) / 9)
print(f"A temperatura em {F}ºF é equivalente a {round(C,2)} ºC.")