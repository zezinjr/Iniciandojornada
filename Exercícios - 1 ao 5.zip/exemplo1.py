ganho_por_hora = float(input("Digite o quanto você ganha por hora:"))
horas_trabalhadas = float(input("Digite a quantidade de horas trabalhadas:"))

salario_mensal = ganho_por_hora * horas_trabalhadas

print(f"Ganhando {ganho_por_hora} reais por hora e trabalhando {horas_trabalhadas} horas, receberá no mês {round(salario_mensal,2)} reais.")